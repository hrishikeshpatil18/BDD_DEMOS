package com.capg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.pom.PageObjectRepository;
import com.capg.pom.WebPOM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	
	WebDriver driver;
	PageObjectRepository pageFactory;
	
	
	@Given("^Open browser and enter the icopmpass URL$")
	public void open_browser_and_enter_the_icopmpass_URL() throws Throwable {
		
		
		driver = WebPOM.getWebDriver();
		
		String url = "https://icompassweb.fs.capgemini.com";
	
		driver.get(url);
		pageFactory = new PageObjectRepository(driver);
	   
	}
	
	

	@When("^user enters valid user name \"([^\"]*)\" and password \"([^\"]*)\"$")
	public void user_enters_valid_user_name_and_password(String username, String password) throws Throwable {
		
		/*WebElement userfield = WebPOM.getUserField();
		userfield.sendKeys(username);
		
		WebElement passwordfield = WebPOM.getPasswordField();
		passwordfield.sendKeys(password);*/
		
		WebElement userfield = pageFactory.getUserField();
		userfield.sendKeys(username);
		
		WebElement passwordfield = pageFactory.getPasswordField();
		passwordfield.sendKeys(password);
		
	
	}
	
	
	@Then("^Successfully lopgin to icompass$")
	public void successfully_lopgin_to_icompass() throws Throwable {
		
		/*WebElement loginButton = WebPOM.getLoginButton();
		loginButton.click();*/
		
		WebElement loginButton = pageFactory.getLoginButton();
		loginButton.click();
	   
	}

	

}
