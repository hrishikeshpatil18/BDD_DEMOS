package com.capg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.pom.BackLinkPageFactory;
import com.capg.pom.PageObjectRepository;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BackLinkStepDefinition {
	
	WebDriver driver;
	BackLinkPageFactory pageFactory;
	
	
	@Given("^user is on subject categories page$")
	public void user_is_on_subject_categories_page() throws Throwable {
		
		driver = pageFactory.getWebDriver();
		
		String url = "C:\\Users\\hripatil\\VV AT M4_MPT Sample Que\\login.html";
	
		driver.get(url);
		pageFactory = new BackLinkPageFactory(driver);
	 
	}
	
	@When("^user clicks on the given links$")
	public void user_clicks_on_the_given_links() throws Throwable {
		
		WebElement link = pageFactory.getLink();
		link.click();
	   
	}

	@Then("^navigate to the next page$")
	public void navigate_to_the_next_page() throws Throwable {
	    
	}

	

	@When("^user clicks on the given back link$")
	public void user_clicks_on_the_given_back_link() throws Throwable {
		
		
	    
	}

	@Then("^navigate to login page$")
	public void navigate_to_login_page() throws Throwable {
	   
	}

}
