package com.capg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.pom.PageObjectRepository;


import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {

	WebDriver driver;
	PageObjectRepository pageFactory;
	
	
	
	@Given("^user is on login page$")
	public void user_is_on_login_page() throws Throwable {
		
		
		driver = pageFactory.getWebDriver();
		
		String url = "C:\\Users\\hripatil\\VV AT M4_MPT Sample Que\\login.html";
	
		driver.get(url);
		pageFactory = new PageObjectRepository(driver);
		
	   
	}

	@When("^user enters invalid username \"([^\"]*)\" and password \"([^\"]*)\"$")
	public void user_enters_invalid_username_and_password(String username, String password) throws Throwable {
		
		WebElement userfield = pageFactory.getUserField();
		userfield.sendKeys(username);
		
		WebElement passwordfield = pageFactory.getPasswordField();
		passwordfield.sendKeys(password);
	   
	}

	@Then("^displays 'Please enter the valid username and password'$")
	public void displays_Please_enter_the_valid_username_and_password() throws Throwable {
	   
		WebElement loginButton = pageFactory.getLoginButton();
		loginButton.click();
		
	}

	@When("^user enters valid userame \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_enters_valid_userame_and_valid_password(String username, String password) throws Throwable {
	  
		WebElement userfield = pageFactory.getUserField();
		userfield.sendKeys(username);
		
		WebElement passwordfield = pageFactory.getPasswordField();
		passwordfield.sendKeys(password);
		
	}

	@Then("^successfully login to$")
	public void successfully_login_to() throws Throwable {
		
		WebElement loginButton = pageFactory.getLoginButton();
		loginButton.click();
	   
	   
	}

	
	
}
