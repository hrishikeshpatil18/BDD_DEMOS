package com.capg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.capg.pom.FormPageFactory;
import com.capg.pom.PageObjectRepository;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class formStepDefinition {
	
	WebDriver driver;
	FormPageFactory pageFactory;
	
	
	@Given("^user is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
		
		driver = pageFactory.getWebDriver();
		
		String url = "C:\\Users\\hripatil\\VV AT M4_MPT Sample Que\\registration.html";
	
		driver.get(url);
		pageFactory = new FormPageFactory(driver);
		
	   
	}

	@When("^user enters valid full name \"([^\"]*)\"$")
	public void user_enters_valid_full_name(String name) throws Throwable {
		
		WebElement nameField = pageFactory.getNameField();
		nameField.sendKeys(name);
	   
	}

	@Then("^displays 'Valid name'$")
	public void displays_Valid_name() throws Throwable {
		
		WebElement button = pageFactory.getConfirmButton();
		button.click();
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid email \"([^\"]*)\"$")
	public void user_enters_valid_email(String mail) throws Throwable {
	  
		WebElement mailField = pageFactory.getMailField();
		mailField.sendKeys(mail);
	}

	@Then("^displays 'Valid email'$")
	public void displays_Valid_email() throws Throwable {
	    
		
		WebElement button = pageFactory.getConfirmButton();
		button.click();
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid  mobile No \"([^\"]*)\"$")
	public void user_enters_valid_mobile_No(String phn) throws Throwable {
	  
		WebElement phoneField = pageFactory.getPhoneField();
		phoneField.sendKeys(phn);
	}

	@Then("^displays 'Valid phone number'$")
	public void displays_Valid_phone_number() throws Throwable {
	  
		
		WebElement button = pageFactory.getConfirmButton();
		button.click();
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid subject category \"([^\"]*)\"$")
	public void user_enters_valid_subject_category(String arg1) throws Throwable {
		
		WebElement category = pageFactory.getSubCategory();
		category.sendKeys(arg1);
	}

	@Then("^displays 'Valid subject category'$")
	public void displays_Valid_subject_category() throws Throwable {
	  
		WebElement button = pageFactory.getConfirmButton();
		button.click();
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid  paper name \"([^\"]*)\"$")
	public void user_enters_valid_paper_name(String pprName) throws Throwable {
	    
		WebElement paperNameField = pageFactory.getPaperName();
		paperNameField.sendKeys(pprName);
	}

	@Then("^displays 'Valid paper name'$")
	public void displays_Valid_paper_name() throws Throwable {
	    
		WebElement button = pageFactory.getConfirmButton();
		button.click();
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid no of authors \"([^\"]*)\"$")
	public void user_enters_valid_no_of_authors(String noOfAuthors) throws Throwable {
		
		WebElement authors = pageFactory.getNoOfAuthors();
		authors.sendKeys(noOfAuthors);
	  
	}

	@Then("^displays 'Valid no of authors'$")
	public void displays_Valid_no_of_authors() throws Throwable {
	 
		WebElement button = pageFactory.getConfirmButton();
		button.click();
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid company name \"([^\"]*)\"$")
	public void user_enters_valid_company_name(String cName) throws Throwable {
	   
		WebElement companyName = pageFactory.getCompanyName();
		companyName.sendKeys(cName);
	}

	@Then("^displays 'Valid company name'$")
	public void displays_Valid_company_name() throws Throwable {
	   
		WebElement button = pageFactory.getConfirmButton();
		button.click();
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid designation \"([^\"]*)\"$")
	public void user_enters_valid_designation(String des) throws Throwable {
		
		WebElement designation = pageFactory.getDesignation();
		designation.sendKeys(des);
	   
	}

	@Then("^displays 'Valid designation'$")
	public void displays_Valid_designation() throws Throwable {
	  
		WebElement button = pageFactory.getConfirmButton();
		button.click();
		driver.switchTo().alert().accept();
		driver.close();
	}

	
	@When("^user enters valid gender$")
	public void user_enters_valid_gender() throws Throwable {
	   
		WebElement gender = pageFactory.getGender();
		gender.click();
		
	}

	@Then("^displays 'Valid gender'$")
	public void displays_Valid_gender() throws Throwable {
	   

		WebElement button = pageFactory.getConfirmButton();
		button.click();
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid city$")
	public void user_enters_valid_city() throws Throwable {
	   
		WebElement city = pageFactory.getCity();
		Select select=new Select(city);
		select.selectByValue("Pune");
	}

	@Then("^displays 'Valid city'$")
	public void displays_Valid_city() throws Throwable {
		WebElement button = pageFactory.getConfirmButton();
		button.click();	
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid state$")
	public void user_enters_valid_state() throws Throwable {
		
		WebElement state = pageFactory.getState();
		Select select=new Select(state);
		select.selectByValue("Maharashtra");
	}

	@Then("^displays 'Valid state'$")
	public void displays_Valid_state() throws Throwable {
		WebElement button = pageFactory.getConfirmButton();
		button.click();
		driver.switchTo().alert().accept();
		driver.close();
	}

	
	
	
	@When("^user enters invalid full name \"([^\"]*)\"$")
	public void user_enters_invalid_full_name(String name) throws Throwable {
	   
		WebElement name1 = pageFactory.getDesignation();
		name1.sendKeys(name);
	}

	@Then("^displays 'inValid name'$")
	public void displays_inValid_name() throws Throwable {
	   
		WebElement button = pageFactory.getConfirmButton();
		button.click();
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid email \"([^\"]*)\"$")
	public void user_enters_invalid_email(String arg1) throws Throwable {
	  
		WebElement mail1 = pageFactory.getDesignation();
		mail1.sendKeys(arg1);
	}

	@Then("^displays 'inValid email'$")
	public void displays_inValid_email() throws Throwable {
	   
		WebElement button = pageFactory.getConfirmButton();
		button.click();
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid  mobile No \"([^\"]*)\"$")
	public void user_enters_invalid_mobile_No(String arg1) throws Throwable {
	   
		WebElement mobile1 = pageFactory.getDesignation();
		mobile1.sendKeys(arg1);
	}

	@Then("^displays 'inValid phone number'$")
	public void displays_inValid_phone_number() throws Throwable {
	   
		WebElement button = pageFactory.getConfirmButton();
		button.click();
		driver.switchTo().alert().accept();
		driver.close();
	}


}
