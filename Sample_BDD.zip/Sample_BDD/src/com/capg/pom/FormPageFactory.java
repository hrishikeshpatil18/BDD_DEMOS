package com.capg.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FormPageFactory {
	
	static WebDriver driver;
	
	@FindBy(id="txtFullName")
	@CacheLookup
	WebElement nameField;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement mailField;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement phoneField;
	
	@FindBy(id="gender")
	@CacheLookup
	WebElement gender;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement state;
	
	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement subCategory;
	
	@FindBy(id="txtDebit")
	@CacheLookup
	WebElement paperName;
	
	@FindBy(id="txtCvv")
	@CacheLookup
	WebElement noOfAuthors;
	
	@FindBy(id="txtMonth")
	@CacheLookup
	WebElement companyName;
	
	@FindBy(id="txtYear")
	@CacheLookup
	WebElement designation;
	
	@FindBy(id="btnPayment")
	@CacheLookup
	WebElement confirmButton;
	
	public FormPageFactory(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	
	public static WebDriver getWebDriver()
	{
		String path = "C:\\\\Users\\\\hripatil\\\\Downloads\\\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		driver = new ChromeDriver();
		
		return driver;
	}


	public WebElement getNameField() {
		return nameField;
	}


	public void setNameField(WebElement nameField) {
		this.nameField = nameField;
	}


	public WebElement getMailField() {
		return mailField;
	}


	public void setMailField(WebElement mailField) {
		this.mailField = mailField;
	}


	public WebElement getPhoneField() {
		return phoneField;
	}


	public void setPhoneField(WebElement phoneField) {
		this.phoneField = phoneField;
	}


	public WebElement getGender() {
		return gender;
	}


	public void setGender(WebElement gender) {
		this.gender = gender;
	}


	public WebElement getCity() {
		return city;
	}


	public void setCity(WebElement city) {
		this.city = city;
	}


	public WebElement getState() {
		return state;
	}


	public void setState(WebElement state) {
		this.state = state;
	}


	public WebElement getSubCategory() {
		return subCategory;
	}


	public void setSubCategory(WebElement subCategory) {
		this.subCategory = subCategory;
	}


	public WebElement getPaperName() {
		return paperName;
	}


	public void setPaperName(WebElement paperName) {
		this.paperName = paperName;
	}


	public WebElement getNoOfAuthors() {
		return noOfAuthors;
	}


	public void setNoOfAuthors(WebElement noOfAuthors) {
		this.noOfAuthors = noOfAuthors;
	}


	public WebElement getCompanyName() {
		return companyName;
	}


	public void setCompanyName(WebElement companyName) {
		this.companyName = companyName;
	}


	public WebElement getDesignation() {
		return designation;
	}


	public void setDesignation(WebElement designation) {
		this.designation = designation;
	}


	public WebElement getConfirmButton() {
		return confirmButton;
	}


	public void setConfirmButton(WebElement confirmButton) {
		this.confirmButton = confirmButton;
	}
	
	
	
	

}
