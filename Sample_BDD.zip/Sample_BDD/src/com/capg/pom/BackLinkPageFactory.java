package com.capg.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BackLinkPageFactory {
	
	
static WebDriver driver;
	
	@FindBy(linkText="Click here to know the Subject Categories")
	@CacheLookup
	WebElement link;
	
	@FindBy(linkText="back")
	@CacheLookup
	WebElement backLink;
	
	
	public BackLinkPageFactory(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	
	public static WebDriver getWebDriver()
	{
		String path = "C:\\\\Users\\\\hripatil\\\\Downloads\\\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		driver = new ChromeDriver();
		
		return driver;
	}


	public WebElement getLink() {
		return link;
	}


	public void setLink(WebElement link) {
		this.link = link;
	}


	public WebElement getBackLink() {
		return backLink;
	}


	public void setBackLink(WebElement backLink) {
		this.backLink = backLink;
	}
	
	
	
	
	

}
