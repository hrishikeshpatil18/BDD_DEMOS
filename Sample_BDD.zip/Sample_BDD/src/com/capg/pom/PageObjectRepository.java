package com.capg.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageObjectRepository {

	static WebDriver driver;
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement userField;
	
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement passwordField;
	
	@FindBy(how=How.CLASS_NAME , using="btn")
	@CacheLookup
	WebElement loginButton;
	
	public PageObjectRepository(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	
	public static WebDriver getWebDriver()
	{
		String path = "C:\\\\Users\\\\hripatil\\\\Downloads\\\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		driver = new ChromeDriver();
		
		return driver;
	}


	public WebElement getUserField() {
		return userField;
	}


	public void setUserField(WebElement userField) {
		this.userField = userField;
	}


	public WebElement getPasswordField() {
		return passwordField;
	}


	public void setPasswordField(WebElement passwordField) {
		this.passwordField = passwordField;
	}


	public WebElement getLoginButton() {
		return loginButton;
	}


	public void setLoginButton(WebElement loginButton) {
		this.loginButton = loginButton;
	}
	
	
	
	
	

}
