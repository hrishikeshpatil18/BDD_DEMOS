package com.capg;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\hripatil\\Module 4 Workspace\\Sample_BDD\\src\\linkTest.feature")
public class BackLink {
	
	
		public static void main(String args[])
		{
			
		}

	}



