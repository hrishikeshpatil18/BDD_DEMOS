package com.capg.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterPageRepo {

	static WebDriver driver;

	@FindBy(name = "txtFN")
	@CacheLookup
	WebElement name;

	@FindBy(name = "Email")
	@CacheLookup
	WebElement emailField;

	@FindBy(name = "Phone")
	@CacheLookup
	WebElement mobileField;

	@FindBy(name = "gender")
	@CacheLookup
	WebElement genderField;

	@FindBy(name = "city")
	@CacheLookup
	WebElement cityFieled;

	@FindBy(name = "state")
	@CacheLookup
	WebElement stateField;

	@FindBy(id = "txtCardholderName")
	@CacheLookup
	WebElement subjectField;

	@FindBy(name = "debit")
	@CacheLookup
	WebElement paperField;

	@FindBy(name = "cvv")
	@CacheLookup
	WebElement authorField;

	@FindBy(id = "txtYear")
	@CacheLookup
	WebElement designationField;

	@FindBy(id = "txtMonth")
	@CacheLookup
	WebElement companyField;

	@FindBy(id = "btnPayment")
	@CacheLookup
	WebElement buttonField;

	public RegisterPageRepo(WebDriver driver) {

		PageFactory.initElements(driver, this);

	}

	public WebElement getGenderField() {
		return genderField;
	}

	public WebElement getName() {
		return name;
	}

	public void setName(WebElement name) {
		this.name = name;
	}

	public WebElement getEmailField() {
		return emailField;
	}

	public void setEmailField(WebElement emailField) {
		this.emailField = emailField;
	}

	public WebElement getMobileField() {
		return mobileField;
	}

	public void setMobileField(WebElement mobileField) {
		this.mobileField = mobileField;
	}

	public WebElement getCityFieled() {
		return cityFieled;
	}

	public void setCityFieled(WebElement cityFieled) {
		this.cityFieled = cityFieled;
	}

	public WebElement getStateField() {
		return stateField;
	}

	public void setStateField(WebElement stateField) {
		this.stateField = stateField;
	}

	public WebElement getSubjectField() {
		return subjectField;
	}

	public void setSubjectField(WebElement subjectField) {
		this.subjectField = subjectField;
	}

	public WebElement getPaperField() {
		return paperField;
	}

	public void setPaperField(WebElement paperField) {
		this.paperField = paperField;
	}

	public WebElement getAuthorField() {
		return authorField;
	}

	public void setAuthorField(WebElement authorField) {
		this.authorField = authorField;
	}

	public WebElement getDesignationField() {
		return designationField;
	}

	public void setDesignationField(WebElement designationField) {
		this.designationField = designationField;
	}

	public WebElement getCompanyField() {
		return companyField;
	}

	public void setCompanyField(WebElement companyField) {
		this.companyField = companyField;
	}

	public WebElement getButtonField() {
		return buttonField;
	}

	public void setButtonField(WebElement buttonField) {
		this.buttonField = buttonField;
	}

	public void setGenderField(WebElement genderField) {
		this.genderField = genderField;
	}

}
