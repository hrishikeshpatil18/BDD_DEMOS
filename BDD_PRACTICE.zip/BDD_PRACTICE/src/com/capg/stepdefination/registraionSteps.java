package com.capg.stepdefination;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.capg.pom.RegisterPageRepo;
import com.capg.pom.WebPOM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class registraionSteps {
	static WebDriver driver;
	static RegisterPageRepo pom;

	@Given("^Open any browser and enter URL$")
	public void open_any_browser_and_enter_URL() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		driver = WebPOM.getWebDriver();

		String url = "C:\\BDD WorkSpace\\PracticeDemo\\src\\registration.html";
		driver.get(url);
		pom = new RegisterPageRepo(driver);
	}

	@When("^User Enter FullName \"([^\"]*)\" email \"([^\"]*)\" mobile no \"([^\"]*)\"$")
	public void user_Enter_FullName_email_mobile_no(String name, String email, String mobile) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		WebElement nameField = pom.getName();
		nameField.sendKeys(name);

		WebElement emailField = pom.getEmailField();
		emailField.sendKeys(email);

		WebElement mobileField = pom.getMobileField();
		mobileField.sendKeys(mobile);

	}

	@When("^select gender as male city as Pune then state as maharashtra$")
	public void select_gender_as_male_city_as_Pune_then_state_as_maharashtra() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		WebElement gender = pom.getGenderField();
		gender.click();

		WebElement city = pom.getCityFieled();

		WebElement state = pom.getStateField();

		Select sel1 = new Select(city);
		Select sel2 = new Select(state);

		sel1.selectByValue("Pune");
		sel2.selectByValue("Maharashtra");

	}

	@When("^select gender as male and state as maharashtra$")
	public void select_gender_as_male_and_state_as_maharashtra() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		WebElement gender = pom.getGenderField();
		gender.click(); 								// valid city
														// for invalid city
		WebElement state = pom.getStateField();

		Select sel2 = new Select(state);

		sel2.selectByValue("Maharashtra");
	}

	@When("^select invalid city$")
	public void select_invalid_city() throws Throwable {
		// Write code here that turns the phrase above into concrete actions 				//invalid
																							// city
		WebElement city = pom.getCityFieled();
		Select dd1 = new Select(city);
		dd1.selectByValue("");
	}

	@When("^subject category as \"([^\"]*)\" paper name as  \"([^\"]*)\" and enter no\\.of author as \"([^\"]*)\"$")
	public void subject_category_as_paper_name_as_and_enter_no_of_author_as(String subject, String paper, String author)
			throws Throwable {

		WebElement subjectfield = pom.getSubjectField();
		subjectfield.sendKeys(subject);

		WebElement paperField = pom.getPaperField();
		paperField.sendKeys(paper);

		WebElement authorField = pom.getAuthorField();
		authorField.sendKeys(author);

	}

	@When("^company name as \"([^\"]*)\" and designation as \"([^\"]*)\"$")
	public void company_name_as_and_designation_as(String company, String designation) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		WebElement companyField = pom.getCompanyField();
		companyField.sendKeys(company);

		WebElement designationField = pom.getDesignationField();
		designationField.sendKeys(designation);

	}

	@Then("^Registration confirm Successfully$")
	public void registration_confirm_Successfully() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		WebElement regiterButton = pom.getButtonField();

		regiterButton.click();
		
		driver.switchTo().alert().accept();
		driver.close();

	}

}
