package com.capg.stepdefination;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.pom.PageObjectRepository;
import com.capg.pom.WebPOM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {

	static WebDriver driver;

	PageObjectRepository pageFactory;

	@Given("^user is on 'Paper submission for International Jounal' page$")
	public void user_is_on_Paper_submission_for_International_Jounal_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		driver = WebPOM.getWebDriver();

		String url = "C:\\BDD WorkSpace\\PracticeDemo\\src\\login.html";
		driver.get(url);

		pageFactory = new PageObjectRepository(driver);

	}

	@When("^user enteres invalid username \"([^\"]*)\"  and invalid password \"([^\"]*)\"$")
	public void user_enteres_invalid_username_and_invalid_password(String username, String password) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		WebElement userFiled = pageFactory.getUserField();
		userFiled.sendKeys(username);

		WebElement passwordField = pageFactory.getPasswordField();
		passwordField.sendKeys(password);
	}

	@Then("^the alert box displays 'Please enter correct Details'$")
	public void the_alert_box_displays_Please_enter_correct_Details() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		WebElement loginButton = WebPOM.getLoginButtton();
		loginButton.click();

		
	}

	@When("^user enteres valid username \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_enteres_valid_username_and_valid_password(String username, String password) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		WebElement userFiled = pageFactory.getUserField();
		userFiled.sendKeys(username);

		WebElement passwordField = pageFactory.getPasswordField();
		passwordField.sendKeys(password);
	}

	@Then("^succefully login to Form$")
	public void succefully_login_to_Form() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		WebElement loginButton = WebPOM.getLoginButtton();
		loginButton.click();
		
	}

}
