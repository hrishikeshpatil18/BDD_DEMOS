package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AlertDemo {

	public static void main(String[] args) {

		WebDriver driver = WebUtil.getWebDriver();

		driver.get("C:\\Users\\hripatil\\Module 4 Workspace\\SeleniumWebDriver\\html\\AlertExample.html");

		WebElement element = driver.findElement(By.name("btnAlert"));
		 element.click();

		// WebDriverWait wait = new WebDriverWait(driver, 5);

		// driver.findElement(By.name("btnAlert")).click();

		/*
		 * String alertText = driver.switchTo().alert().getText();
		 * 
		 * System.out.println(alertText);
		 */

		// driver.switchTo().alert().sendKeys("Hrishi");

		// driver.switchTo().alert().accept();

		try {
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.alertIsPresent());
			String alrt = driver.switchTo().alert().getText();
			System.out.print(alrt);
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
