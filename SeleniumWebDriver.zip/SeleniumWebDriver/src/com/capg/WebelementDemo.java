package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class WebelementDemo {
	
	public static void main(String agrs[])
	{
		
		WebDriver driver  = WebUtil.getWebDriver();
		
		driver.navigate().to("https://www.toolsqa.com/automation-practice-form");
		/*WebElement link1 =	driver.findElement(By.partialLinkText("SELENIUM"));
		link1.click();
		
		driver.navigate().back();*/
		
		/*WebElement link2 =	driver.findElement(By.linkText("ABOUT"));
		link2.click();*/
		
		/*WebElement gender =	driver.findElement(By.id("sex-0"));
		gender.click();*/
		
		/*WebElement checkbox =	driver.findElement(By.id("profession-0"));
		checkbox.click();*/
		
		Select continents =new Select(driver.findElement(By.xpath("//*[@id=\"continents\"]")));
        continents.selectByValue("AUS");
        
        Select continentsmultiple =new Select(driver.findElement(By.id("continentsmultiple")));
        continentsmultiple.selectByValue("AUS");
        continentsmultiple.selectByValue("NA");
		
	}

}
