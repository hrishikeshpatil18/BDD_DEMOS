package com.capg;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;

public class JSDemo {
	
	public static void main(String args[])
	{
	
		WebDriver driver = WebUtil.getWebDriver();
		
		//driver.get("C:\\Users\\hripatil\\Module 4 Workspace\\SeleniumWebDriver\\html\\demo.html");
		driver.get("http://www.wikipedia.org//wiki/India");
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,200)");
		//jse.executeScript("display()");
		
		/*String str = jse.executeScript("return document.getElementById('h1').innerHTML").toString();
		System.out.println(str);*/
	
	}

}
