package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MultiWindows {

	public static void main(String[] args) {
	
		WebDriver driver = WebUtil.getWebDriver();
		
		driver.get("C:\\Users\\hripatil\\Module 4 Workspace\\SeleniumWebDriver\\html\\PopupWin.html");
		
		String parentWindow = driver.getWindowHandle();
		driver.findElement(By.name("Open")).click();			//automatically clicks btn and switch to next child window
		
		driver.switchTo().window("PopupWindow");
		
		driver.findElement(By.name("txtName")).sendKeys("Hrishi");		//sending keys to alert textfield
		driver.findElement(By.name("btnAlert")).click();
		
		driver.switchTo().alert().accept();
		driver.close();
		
		driver.switchTo().window(parentWindow);					//returns to parent window

	}

}
