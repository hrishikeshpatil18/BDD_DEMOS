package com.capg;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class JSDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = WebUtil.getWebDriver();
		
		//driver.get("C:\\BDD WorkSpace\\SeleniumWebDriver\\html\\demo.html");
		
		driver.get("http://www.wikipedia.org/wiki/India");
		
		JavascriptExecutor jse = (JavascriptExecutor)  driver;
		
		jse.executeScript("window.scrollBy(0,200)");
		
	//	jse.executeScript("display()");
		
		//jse.executeScript("history.get(0)");
		

	}

}
