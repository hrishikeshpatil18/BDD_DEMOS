package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AlertDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = WebUtil.getWebDriver();

		driver.get("C:\\BDD WorkSpace\\SeleniumWebDriver\\html\\AlertExample.html");

		WebElement element = driver.findElement(By.name("btnAlert"));
		//element.click();
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/*try {
		
		WebDriverWait wait = new WebDriverWait(driver, 5);

		wait.until(ExpectedConditions.alertIsPresent());

		String alertText = driver.switchTo().alert().getText();
		System.out.println(alertText);
		}
		catch(Exception e) {
			System.out.println(e);
		}
*/
	}

}
