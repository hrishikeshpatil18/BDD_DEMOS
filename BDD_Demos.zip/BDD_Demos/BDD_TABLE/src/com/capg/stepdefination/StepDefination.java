package com.capg.stepdefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {
	
	WebDriver driver;
	
	@Given("^Navigate to Icompass URL to display logIn page$")
	public void navigate_to_Icompass_URL_to_display_logIn_page() throws Throwable {
		driver = WebUtil.getWebDriver();
		String url = "https://icompassweb.fs.capgemini.com";
		driver.get(url);
	}

	@When("^User Enter login credentials username \"([^\"]*)\" and password \"([^\"]*)\"$")
	public void user_Enter_login_credentials_username_and_password(String username, String password) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement userField = driver.findElement(By.id("userName"));

		WebElement passwordField = driver.findElement(By.id("password"));

		userField.sendKeys(username);
		passwordField.sendKeys(password);
	}

	@Then("^Validation should be Performed$")
	public void validation_should_be_Performed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement loginButton = driver.findElement(By.id("loginButton"));
		loginButton.click();
		driver.close();
	}

	

}
