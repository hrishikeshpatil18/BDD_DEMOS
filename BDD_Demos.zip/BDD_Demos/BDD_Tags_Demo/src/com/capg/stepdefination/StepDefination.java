package com.capg.stepdefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {

	WebDriver driver;

	@Given("^Navaigate to icomapss URL$")
	public void navaigate_to_icomapss_URL() throws Throwable {

		driver = WebUtil.getWebDriver();
		String url = "https://icompassweb.fs.capgemini.com";
		driver.get(url);

	}

	@When("^User Enter Valid username \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_Enter_Valid_username_and_valid_password(String username, String password) throws Throwable {

		WebElement userField = driver.findElement(By.id("userName"));

		WebElement passwordField = driver.findElement(By.id("password"));

		userField.sendKeys(username);
		passwordField.sendKeys(password);

	}

	@Then("^Login successfully$")
	public void login_successfully() throws Throwable {

		WebElement loginButton = driver.findElement(By.id("loginButton"));
		loginButton.click();
		driver.close();
	}

	@Given("^Navaigate to Google URL$")
	public void navaigate_to_Google_URL() throws Throwable {
		driver = WebUtil.getWebDriver();
		String url = "https://www.google.com";
		driver.navigate().to(url);
	}

	@When("^User Enter input \"([^\"]*)\"$")
	public void user_Enter_input(String input) throws Throwable {

		WebElement searchField = driver.findElement(By.name("q"));
		searchField.sendKeys(input);
		searchField.sendKeys("\n");
	}

	@Then("^Climate details Display$")
	public void climate_details_Display() throws Throwable {

		System.out.println("Cliamte Deatils Displayed");
		driver.close();
	}

	@When("^User click on Image Link$")
	public void user_click_on_Image_Link() throws Throwable {

		WebElement imageLink = driver.findElement(By.className("gb_e"));
		imageLink.click();

	}

	@Then("^Display Image Page$")
	public void display_Image_Page() throws Throwable {
		System.out.println("Images Displayed");

	}

}
