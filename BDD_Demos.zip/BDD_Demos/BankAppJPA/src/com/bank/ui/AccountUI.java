package com.bank.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.bank.bean.Account;
import com.bank.bean.Customer;
import com.bank.service.AccountService;

public class AccountUI {
	
	List<String> arrlist=new ArrayList<String>();
	Scanner sc = new Scanner(System.in);
	AccountService accServ= new AccountService();
	Customer cust = new Customer();
	Account account= new Account();
	
	//Adding Customer
	static int accNo=100;
	static int custId=0;
	public void addAccount() {
		System.out.println("Enter the Account Holder Name");
		String name= sc.next();
		System.out.println("Enter the Mobile Number");
		long mob= sc.nextLong();
		cust.setName(name);
		cust.setMobileNum(mob);
		//cust.setCustId(++custId);
		//account.setAccountNo(++accNo);
		cust.setAccount(account);
		accServ.addAccount(cust);
		System.out.println("Account Added Successfully");
		System.out.println("Your Account Number :"+account.getAccountNo());
		
		arrlist.add("Account added :"+account.getAccountNo());
	}
	
	//Show Balance
	public void showBaL(int accNo) {
		Account accBal=accServ.getAcc(accNo);
		System.out.println("Available Balance :"+accBal.getBalance());
	}
	
	//Amount Deposit to Account 
	public void deposit() {
		System.out.println("Enter Account Number");
		int accNo=sc.nextInt();
		Account acc=accServ.getAcc(accNo);
		double currBal=acc.getBalance();
		System.out.println("Enter the Amount want to Deposit");
		double amount=sc.nextDouble();
		double totalBal=currBal+amount;
		acc.setBalance(totalBal);
		accServ.deposit(acc);
		System.out.println("Amount"+amount+"deposited to you Account");
		
		arrlist.add("Amount"+amount+"Deposited to Account"+accNo );
	}
	
	//Withdraw from the Account
	public void withdrwal() {
		System.out.println("Enter the Account Number");
		int accNo=sc.nextInt();
		Account acc=accServ.getAcc(accNo);
		System.out.println("Available Balance :"+acc.getBalance());
		System.out.println("Enter the withdrawl Amount");
		double withBal=sc.nextDouble();
		double currBal=acc.getBalance();
		if(withBal<currBal) {
			double finalBal=currBal-withBal;
			acc.setBalance(finalBal);
			accServ.withdrawl(acc);
			System.out.println("Withdrawl Successfully");
			
			arrlist.add("Withdrawl"+withBal+"Successfully from Account"+accNo);
		}
		else
			System.out.println("Available Balance Low");
	}
	
	//Fund Transfer
	public void fundTransfer() {
		System.out.println("Enter the Sender Account Number");
		int accNo1=sc.nextInt();
		Account acc1=accServ.getAcc(accNo1);
		System.out.println("Available Balance "+acc1.getBalance());
		System.out.println("Enter the Reciever Account Number");
		int accNo2=sc.nextInt();
		Account acc2=accServ.getAcc(accNo2);
		System.out.println("Enter the Transfer Amount");
		double transferAmt=sc.nextDouble();
		double currBalaccNo1=acc1.getBalance();
		if(transferAmt<currBalaccNo1) {
			double totalAmt2=acc2.getBalance()+transferAmt;
			double totalAmt1=currBalaccNo1-transferAmt;
			acc1.setBalance(totalAmt1);
			acc2.setBalance(totalAmt2);
			accServ.fundTransfer(acc1);
			accServ.fundTransfer(acc2);
			System.out.println("Fund Transfer successfully");
			
			arrlist.add("Fund Transfer Successfully from"+accNo1+"To"+accNo2);
		}
		else
			System.out.println("Available Balance Low");
	}
	
	//Print Transaction
	public void printTransaction() {
		Iterator itr=arrlist.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}

}
