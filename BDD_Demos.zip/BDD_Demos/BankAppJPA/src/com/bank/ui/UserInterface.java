package com.bank.ui;

import java.util.Scanner;

import javax.persistence.EntityManager;

import com.bank.dao.JpaUtil;
import com.bank.service.AccountService;

public class UserInterface {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		AccountUI accUi = new AccountUI();
		int choice=0;
		while(choice!=7) {
			System.out.println();
			System.out.println("\tWELCOME TO OUR MINI PROJECT BANK\n");
			System.out.println("\tSERVICES AVAILABLE");
			System.out.println("\t1.Create Account");
			System.out.println("\t2.Show Balance");
			System.out.println("\t3.Deposit");
			System.out.println("\t4.Withdrawl");
			System.out.println("\t5.Fund Transfer");
			System.out.println("\t6.Print Transaction");
			System.out.println("\t7.EXIT");
			System.out.println("Enter Your Choice");
			choice=sc.nextInt();
			switch(choice)
			{
				case 1:
					System.out.println("Enter the Following Details");
					accUi.addAccount();
					break;
				case 2:
					System.out.println("Enter the Account Number");
					int accBal=sc.nextInt();
					accUi.showBaL(accBal);
					break;
				case 3:
					accUi.deposit();
					break;
				case 4:
					accUi.withdrwal();
					break;
				case 5:
					accUi.fundTransfer();
					break;
				case 6:
					accUi.printTransaction();
					break;
				case 7:
					System.out.println("BYE");
					break;
				default :
					System.out.println("ERROR");
					System.out.println("Please Try Again");
			}
		}
	}

}
