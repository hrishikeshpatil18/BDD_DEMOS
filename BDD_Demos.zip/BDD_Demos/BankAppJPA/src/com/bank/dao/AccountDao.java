package com.bank.dao;

import javax.persistence.EntityManager;

import com.bank.bean.Account;
import com.bank.bean.Customer;

public class AccountDao {
	
	EntityManager entityManager;
	
	public AccountDao() {
		this.entityManager = JpaUtil.getEntityManager();
	}
	
	//getTransaction
	public void begin() {
		entityManager.getTransaction().begin();
	}
	public void commit() {
		entityManager.getTransaction().commit();
	}
	
	//Adding Customer 
	public void addAccount(Customer cust) {
		entityManager.persist(cust);
	}
	
	//get Account By Account Number
	public Account getAcc(int accNo) {
		Account accBal= entityManager.find(Account.class,accNo);
		return accBal;
	}
	
	//Deposit Balance Updated
	public void deposit(Account acc) {
		entityManager.merge(acc);
	}
	
	//Withdraw Balance Updated
	public void withdrawl(Account acc) {
		entityManager.merge(acc);
	}
	
	//Updating Account
	public void update(Account acc) {
		entityManager.merge(acc);
	}
	

}
