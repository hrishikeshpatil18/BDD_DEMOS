package com.capg.stepdefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefination {

	static WebDriver driver;

	@Given("^Open Browser and enter Flipkart URL$")
	public void open_Browser_and_enter_Flipkart_URL() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String path = "C:\\drivers\\chomedriver1\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);

		driver = new ChromeDriver();

		String url = "https://www.flipkart.com";
		driver.get(url);
	   
	}
	

	@When("^User enters valid username \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_enters_valid_username_and_valid_password(String username, String password) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		WebElement userField = driver.findElement(By.className("_2zrpKA"));
		WebElement passwordField = driver.findElement(By.className("_3v41xv"));

		userField.sendKeys(username);
		passwordField.sendKeys(password);

	}

	
	@Then("^Succesfully Login to Flipkart$")
	public void succesfully_Login_to_Flipkart() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement loginButton = driver.findElement(By.className("_7UHT_c"));
		
		loginButton.click();
		

	}



}
